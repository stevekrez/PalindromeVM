Palindrome System State Capture Script Version 17.04

# 17.03 - 2017-08-01 - removed mutable commands
# 17.04 - 2017-08-29 - added lsof binary 

script requires root context

0. change to root user 
1. unpack the script in /tmp 
2. cd palindrome-system-script-all
3. sh system-state-<OS-Type>.sh
4. wait for step 3 to complete
5. after probing is complete, <hostname>-<epoch>.tar file will be dumped in the current directory. 
