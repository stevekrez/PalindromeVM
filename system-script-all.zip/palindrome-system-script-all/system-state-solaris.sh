#!/usr/bin/bash

# -- Palindrome Static and Dynamic Environment Capture
# -- script assumes root context 
# -- sh system-state-solaris.sh
# -- output <HOSTNAME>-<EPOCH>.tar
# -- Coypright 2017 - Palindrome Technologies Inc.  

# node information
uname -a > ./state/uname_out 2>&1

# system date
date > ./state/date_out 2>&1

# system users 
getent passwd > ./state/system_users_out 2>&1

# login attempts
last > ./state/last_out 2>&1

# installed packages
pkginfo > ./state/pkginfo_out 2>&1
pkginfo -x > ./state/pkginfo_x_out 2>&1
pkginfo -l > ./state/pkginfo_l_out 2>&1


# OpenSSL Ciphers
openssl ciphers -v 'ALL:COMPLEMENTOFALL' > ./state/openssl_ciphers_out 2>&1

# SSH config 
cp /etc/ssh/sshd_config ./state/sshd_config > /dev/null 2>&1

# java info ?
java -version > ./state/java_out 2>&1

# runtime context
set > ./state/set_out 2>&1

# process state
ps aux > ./state/ps_aux_out 2>&1
ps -ef > ./state/ps_ef_out 2>&1
svcs > ./state/svcs_out 2>&1

# open files
pfiles /proc/* > ./state/pfiles_out 2>&1

# network state
ifconfig > ./state/ifconfig_out 2>&1
netstat > ./state/netstat_out 2>&1

# storage state
df > ./state/df_out 2>&1


#########################################
# OUTPUT

echo "Probing system state  ..."

chown -R root:root linux-health
cd linux-health
sh linux-health audit system > /tmp/linux-health-stdout.log  2>&1

cd ..
chown -R $USER:$USER linux-health

# copy linux health report & logs
cp /tmp/linux-health* ./state/

name=`hostname`-`date +%s`
echo "raptor-was-here" > .$name

tar cvf - ./state/*  | gzip -c > $name.tar.gz

chmod 777 *.tar.gz
chmod 777 .$name

echo "Cleaning ..."
echo "Test complete ..."