#!/bin/bash

# -- Palindrome Static and Dynamic Environment Capture
# -- script assumes root context 
# -- sh node-state.sh
# -- output <HOSTNAME>-<EPOCH>.tar
# -- Coypright 2017 - Palindrome Technologies Inc.  

# node information
uname -a > ./state/uname_out 2>&1
lsb_release -a > ./state/lsb_release_out 2>&1

# system date
date > ./state/date_out 2>&1

# system users 
getent passwd > ./state/system_users_out 2>&1

# login attempts
last > ./state/last_out 2>&1
lastlog > ./state/lastlog_out 2>&1

# su attempts
cp /var/log/auth.log ./state/secure > /dev/null 2>&1

# dormant accounts
cp /etc/pam.d/login ./state/pamd_login  > /dev/null 2>&1
cp /etc/pam.d/passwd ./state/pamd_passwd > /dev/null 2>&1
cp /etc/pam.d/common-password ./state/pamd_common-password > /dev/null 2>&1

# password aging
cp /etc/login.defs ./state/login.defs > /dev/null 2>&1

# installed packages
dpkg -l > ./state/dpkg_out 2>&1
apt list --installed > ./state/apt_out 2>&1

# OpenSSL Ciphers
openssl ciphers -v 'ALL:COMPLEMENTOFALL' > ./state/openssl_ciphers_out 2>&1

# SSH config 
cp /etc/ssh/sshd_config ./state/sshd_config > /dev/null 2>&1

# Java 
java -version > ./state/java_version 2>&1

# runtime context

# kernel state
lsmod > ./state/lsmod_out 2>&1

# process state
ps aux > ./state/ps_aux_out 2>&1
# list open files
lsof > ./state/lsof_out 2>&1
# binary as backup
chmod 777 ./bin/lsof
./bin/lsof > ./state/lsof_bin_out 2>&1

# network state
ifconfig > ./state/ifconfig_out 2>&1
netstat -tunlp > ./state/netstat_out 2>&1
ss > ./state/ss_out 2>&1

# storage state
lsblk > ./state/lsblk_out 2>&1
df > ./state/df_out 2>&1

# running services
service --status-all > ./state/service_status_out 2>&1

# /proc file system
cp /proc/cpuinfo ./state/proc_cpuinfo > /dev/null 2>&1
cp /proc/devices ./state/proc_devices > /dev/null 2>&1
cp /proc/dma ./state/proc_dma > /dev/null 2>&1
cp /proc/filesystems ./state/proc_filesystems > /dev/null 2>&1
cp /proc/meminfo ./state/proc_meminfo > /dev/null 2>&1
cp /proc/modules ./state/proc_modules  > /dev/null 2>&1
cp /proc/mounts ./state/proc_mounts  > /dev/null 2>&1
cp /proc/net ./state/proc_net  > /dev/null 2>&1
cp /proc/self ./state/proc_self  > /dev/null 2>&1
cp /proc/stat ./state/proc_stat  > /dev/null 2>&1
cp /proc/uptime ./state/proc_uptime  > /dev/null 2>&1
cp /proc/version ./state/proc_version  > /dev/null 2>&1

# log 
cp /var/log/lastlog ./state/lastlog > /dev/null 2>&1
cp /var/log/mail.log ./state/maillog > /dev/null 2>&1
cp /var/log/messages ./state/messages > /dev/null 2>&1
cp /var/log/secure ./state/secure > /dev/null 2>&1
cp /var/log/apache2/access.log > /dev/null 2>&1
cp /var/log/wtmp ./state/wtmp > /dev/null 2>&1
cp /var/log/btmp ./state/btmp > /dev/null 2>&1
cp /var/run/utmp ./state/utmp > /dev/null 2>&1
cp /var/named/root.hints ./state/root.hints > /dev/null 2>&1


#########################################
spinner()
{
    local pid=$!
    local delay=0.75
    local spinstr='|/-\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

#########################################
# OUTPUT

echo "Probing system state  ..."

chown -R root:root linux-health
cd linux-health
sh linux-health audit system > /tmp/linux-health-stdout.log &
spinner
cd ..
chown -R $USER:$USER linux-health

# copy linux health report & logs
cp /tmp/linux-health* ./state/

name=`hostname`-`date +%s`
echo "raptor-was-here" > .$name

tar czf $name.tar .$name ./state/*

chmod 777 *.tar
chmod 777 .$name

echo "Cleaning ..."
echo "Test complete ..."